package UI.menu;

import model.Client;
import model.valueObjects.Cpf;

public class ClientMenu {

    public static void show(Client client) {

        System.out.println("""

                ===== MENU CLIENTE =====
                Cliente: %s

                1 - Criar conta bancária
                2 - Acessar conta
                3 - Excluir conta bancária
                4 - Excluir conta cliente
                0 - Logout
                """.formatted(client.getName().value()));

        System.out.print("Escolha: ");
    }
}